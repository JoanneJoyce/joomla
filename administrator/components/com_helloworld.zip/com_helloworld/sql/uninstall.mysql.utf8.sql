DROP TABLE IF EXISTS `#__helloworld`;

DROP TABLE IF EXISTS `#__problem_patient`;