INSERT INTO `joomla`.`mpw_problem_patient` (`pid`, `pname`, `furigana`, `bday`, `sex`, `occur_date`, `contents`, `event_level`, `regist_date`, `update_date`) VALUES 
('1000', 'Fred Smith', '�դ��', '820422000', '0', '1513263600', 'Drop Kick Nurse', '0', '1511481600', '1513331717'),
('1001', 'Michael Smith', '�ޤ�����', '359913600', '0', '1122739200', 'Swearing at Nurse', '1', '1511481600', '1511481600'),
('1002', 'Sam Smith', '���ह�ߤ�', '214761600', '0', '1121011200', 'Swearing at Doctor', '0', '1511481600', '1511481600'),
('1003', 'Erica Cochran', '���꤫', '86976000', '1', '1428940800', 'Punch Doctor', '0', '1511481600', '1511481600'),
('1004', 'Allen Loy', '�����', '23212800', '0', '1121356800', 'Slap Doctor', '1', '1511481600', '1511481600'),
('1005', 'Effie Artis', '���դ�', '434649600', '1', '1425484800', 'Kick Doctor', '1', '1511481600', '1511481600'),
('1006', 'Anthony Jacques', '����Ȥ�', '285436800', '0', '1427212800', 'Topple medicine cabinet', '1', '1511481600', '1511481600'),
('1007', 'Julie Lewis', '�����', '535132800', '1', '1426348800', 'Destroy Television', '1', '1511481600', '1511481600');
